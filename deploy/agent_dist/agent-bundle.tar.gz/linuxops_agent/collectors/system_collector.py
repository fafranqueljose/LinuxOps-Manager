"""
LinuxOps Agent — Recolector de Métricas de Sistema y Recursos
Utiliza psutil y archivos de procfs para recopilar métricas sin bloquear.
"""

import os
import platform
import subprocess
import time
from typing import Any, Dict, Optional
import psutil


class SystemCollector:
    @staticmethod
    def get_primary_ip() -> Optional[str]:
        """Detecta la IP principal usada para enrutamiento saliente."""
        try:
            import socket
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.settimeout(0.5)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            pass

        try:
            import socket
            ip = socket.gethostbyname(platform.node())
            if ip and not ip.startswith("127."):
                return ip
        except Exception:
            pass
        return None

    @staticmethod
    def get_hostname() -> str:
        """Obtiene el nombre de host o FQDN del sistema."""
        try:
            import socket
            fqdn = socket.getfqdn()
            if fqdn and fqdn != "localhost":
                return fqdn
        except Exception:
            pass
        return platform.node()

    @staticmethod
    def get_static_os_info() -> Dict[str, Any]:
        """Obtiene información estática del sistema operativo y entorno."""
        os_name = platform.system()
        os_version = platform.release()
        
        # En sistemas Linux, leer /etc/os-release
        if os.path.exists("/etc/os-release"):
            try:
                with open("/etc/os-release", "r") as f:
                    for line in f:
                        if line.startswith("PRETTY_NAME="):
                            os_name = line.split("=", 1)[1].strip().strip('"')
            except Exception:
                pass

        return {
            "hostname": SystemCollector.get_hostname(),
            "ip_address": SystemCollector.get_primary_ip(),
            "os_name": os_name,
            "os_version": platform.release(),
            "kernel": platform.uname().release,
            "architecture": platform.machine(),
            "python_version": platform.python_version(),
        }

    @staticmethod
    def get_live_metrics() -> Dict[str, Any]:
        """Obtiene métricas en tiempo real de CPU, RAM, almacenamiento y carga."""
        # 1. CPU y Uptime
        cpu_pct = psutil.cpu_percent(interval=None)
        cpu_count = psutil.cpu_count(logical=True) or 1
        boot_time = psutil.boot_time()
        uptime_seconds = int(time.time() - boot_time)

        # 2. Memoria RAM
        mem = psutil.virtual_memory()
        
        # 3. Disco principal
        disk = psutil.disk_usage("/")

        # 4. Carga del sistema
        load_1, load_5, load_15 = 0.0, 0.0, 0.0
        if hasattr(os, "getloadavg"):
            try:
                load_1, load_5, load_15 = os.getloadavg()
            except Exception:
                pass

        # 5. Contenedores y servicios fallidos
        failed_count, failed_list = SystemCollector._get_failed_services_info()

        return {
            "hostname": SystemCollector.get_hostname(),
            "ip_address": SystemCollector.get_primary_ip(),
            "uptime_seconds": uptime_seconds,
            "cpu_count": cpu_count,
            "cpu_percent": round(cpu_pct, 1),
            "total_ram_bytes": mem.total,
            "free_ram_bytes": mem.available,
            "ram_percent": round(mem.percent, 1),
            "total_disk_bytes": disk.total,
            "free_disk_bytes": disk.free,
            "disk_percent": round(disk.percent, 1),
            "load_1": round(load_1, 2),
            "load_5": round(load_5, 2),
            "load_15": round(load_15, 2),
            "failed_services_count": failed_count,
            "failed_services_list": failed_list,
        }

    @staticmethod
    def _get_failed_services_info():
        """Obtiene la cantidad y nombres de unidades systemd en estado fallido."""
        try:
            res = subprocess.run(
                ["systemctl", "list-units", "--state=failed", "--no-legend", "--no-pager"],
                capture_output=True,
                text=True,
                timeout=3,
                shell=False,
            )
            if res.returncode == 0:
                failed_units = []
                for line in res.stdout.splitlines():
                    line = line.strip()
                    if not line:
                        continue
                    parts = line.split(maxsplit=4)
                    if parts and parts[0]:
                        unit_name = parts[0]
                        # Limpiar posible prefijo '●'
                        unit_name = unit_name.lstrip("●").strip()
                        failed_units.append(unit_name)
                return len(failed_units), failed_units
        except Exception:
            pass
        return 0, []


system_collector = SystemCollector()

